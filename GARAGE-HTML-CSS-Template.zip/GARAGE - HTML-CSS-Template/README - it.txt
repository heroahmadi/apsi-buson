========================



GARAGE HTML/CSS TEMPLATE 1.0



========================

Autore: Web Domus ITALIA




Twitter: 
http://www.twitter.com/webdomus

Facebook: http://www.facebook.com/webdomusitalia

LinkedIn:http://www.linkedin.com/company/web-domus-italia
 
Sito Web: http://www.webdomus.net/



========================

Rimozione link:

Per favore contattateci se volete rimuovere le attribuzioni dal footer. 
Template creato da: http://www.webdomus.net/


========================


Licenza

- Siete pregati di fare riferiimento al file
 LICENSE.txt 


========================

Questo progetto usa elementi open source:

�	Bootstrap 3.3.6  - http://getbootstrap.com/
�	Google Font
�	Isotope PACKAGED v2.2.2 - http://isotope.metafizzy.co
�	selectordie.js -  Vst.mn
�	Fontawesome - http://fontawesome.io/


Imamagini

�	Unsplash - https://unsplash.com/

Fonts -  Google Fonts
�	Open Sans - https://www.google.com/fonts/specimen/Open+Sans
�	Roboto - https://www.google.com/fonts/specimen/Roboto
�	Bebas Neue Font - http://www.dafont.com/bebas-neue.font

========================

